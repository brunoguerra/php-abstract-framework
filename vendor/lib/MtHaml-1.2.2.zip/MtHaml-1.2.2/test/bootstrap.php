<?php

require __DIR__ . '/../lib/MtHaml/Autoloader.php';

MtHaml\Autoloader::register();

